package com.example.smartlock;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivityFire extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextID;
    private EditText editTextRoomNum;

    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_fire);

        // Initialize Firebase database reference
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Get references to EditText views and the button
        editTextName = findViewById(R.id.editTextName);
        editTextID = findViewById(R.id.editTextID);
        editTextRoomNum = findViewById(R.id.editTextRoomNum);
        Button buttonAddUser = findViewById(R.id.buttonAddUser);
        Button retrieveButton = findViewById(R.id.retrieveButton);

        // Set OnClickListener on the "Add User ID" button
        buttonAddUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get user name, ID, and room number from the EditText views
                String name = editTextName.getText().toString().trim();
                String id = editTextID.getText().toString().trim();
                String roomNum = editTextRoomNum.getText().toString().trim();

                // Check if user name, ID, and room number are not empty
                if (!TextUtils.isEmpty(name) && !TextUtils.isEmpty(id) && !TextUtils.isEmpty(roomNum)) {
                    // Generate a unique ID for the user
                    String userId = mDatabase.push().getKey();

                    // Create a User object with the name, ID, and room number
                    User user = new User(name, id, roomNum);

                    // Save the user data to Firebase database
                    mDatabase.child("users").child(userId).setValue(user)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    // Data successfully saved to database
                                    Toast.makeText(MainActivityFire.this, "User ID added", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    // Data failed to save to database
                                    Toast.makeText(MainActivityFire.this, "Failed to add user ID", Toast.LENGTH_SHORT).show();
                                }
                            });
                }
            }
        });

        // Set OnClickListener on the "Retrieve Data" button
        retrieveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Retrieve data from Firebase
                mDatabase.child("users").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        // Get all users from the "users" node
                        ArrayList<User> users = new ArrayList<>();
                        for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                            User user = dataSnapshot.getValue(User.class);
                            users.add(user);
                        }

                        // Create a string with all the user data
                        StringBuilder stringBuilder = new StringBuilder();
                        for (User user : users) {
                            stringBuilder.append(user.getName()).append(" - ").append(user.getId()).append(" - ").append(user.getRoomNum()).append("\n\n");
                        }

                        // Display the user data in an alert dialog
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivityFire.this);
                        builder.setCancelable(true);
                        builder.setTitle("Requested Data User IDs");
                        builder.setMessage(stringBuilder.toString() + "\n");
                        builder.setPositiveButton("Done", null);
                        builder.show();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        // Handle database error
                        Log.w(TAG, "loadUserIds:onCancelled", databaseError.toException());
                        Toast.makeText(MainActivityFire.this, "Failed to load user IDs.", Toast.LENGTH_SHORT).show();
                    }

                });
            }
        });
    }

    public void deleteUser(View view) {
        // Get the user ID to be deleted from the EditText view
        String idToDelete = editTextID.getText().toString().trim();

        // Check if user ID is not empty
        if (!TextUtils.isEmpty(idToDelete)) {
            // Search for the user in Firebase database
            Query query = mDatabase.child("users").orderByChild("id").equalTo(idToDelete);
            query.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    // Delete the user data from Firebase database
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        snapshot.getRef().removeValue();
                    }

                    // Display a message to indicate the user has been deleted
                    Toast.makeText(MainActivityFire.this, "User deleted", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    // Handle database error
                    Log.w(TAG, "deleteUser:onCancelled", databaseError.toException());
                    Toast.makeText(MainActivityFire.this, "Failed to delete user.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    public void updateUser(View view) {
        // Get the user ID, new name, and new room number from the EditText views
        String idToUpdate = editTextID.getText().toString().trim();
        String newName = editTextName.getText().toString().trim();
        String newRoomNum = editTextRoomNum.getText().toString().trim();

        // Check if user ID, name, and room number are not empty
        if (!TextUtils.isEmpty(idToUpdate) && !TextUtils.isEmpty(newName) && !TextUtils.isEmpty(newRoomNum)) {
            // Search for the user in Firebase database
            Query query = mDatabase.child("users").orderByChild("id").equalTo(idToUpdate);
            query.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    // Update the user data in Firebase database
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        snapshot.getRef().child("name").setValue(newName);
                        snapshot.getRef().child("roomNum").setValue(newRoomNum);
                    }

                    // Display a message to indicate the user has been updated
                    Toast.makeText(MainActivityFire.this, "User updated", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    // Handle database error
                    Log.w(TAG, "updateUser:onCancelled", databaseError.toException());
                    Toast.makeText(MainActivityFire.this, "Failed to update user.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_item1:
                Toast.makeText(getApplicationContext(),"You are taken to Home page", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getBaseContext(), MainActivityHome.class);
                startActivity(intent);
                return true;
            case R.id.menu_item2:
                Toast.makeText(getApplicationContext(),"You are taken to About page", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(getBaseContext(), MainActivityAbt.class);
                startActivity(intent1);
                return true;
            case R.id.menu_item3:
                Toast.makeText(getApplicationContext(),"Thank you, come again !", Toast.LENGTH_SHORT).show();
                Intent intent2 = new Intent(getBaseContext(), MainActivityLgn.class);
                startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
