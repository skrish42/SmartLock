package com.example.smartlock;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivityBlog extends AppCompatActivity {

    TextView t1,t2,t3,t4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_blog);

        t1 = findViewById(R.id.head1);
        t2 = findViewById(R.id.head2);
        t3 = findViewById(R.id.head3);
        t4 = findViewById(R.id.head4);

        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.symmetryelectronics.com/blog/technology-overview-the-iot-smart-lock-symmetry-blog/"));
                startActivity(intent);
            }
        });

        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.allion.com/iot-smart-door-lock/"));
                startActivity(intent);
            }
        });

        t3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://keymitt.com/blogs/keymitt-blog/wi-fi-and-bluetooth-in-iot-smart-lock-systems-and-why-do-we-need-both"));
                startActivity(intent);
            }
        });

        t4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.vivint.com/resources/article/how-do-smart-locks-work"));
                startActivity(intent);
            }
        });

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_item1:
                Toast.makeText(getApplicationContext(),"You are taken to Home page", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getBaseContext(), MainActivityHome.class);
                startActivity(intent);
                return true;
            case R.id.menu_item2:
                Toast.makeText(getApplicationContext(),"You are taken to About page", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(getBaseContext(), MainActivityAbt.class);
                startActivity(intent1);
                return true;
            case R.id.menu_item3:
                Toast.makeText(getApplicationContext(),"Thank you, come again !", Toast.LENGTH_SHORT).show();
                Intent intent2 = new Intent(getBaseContext(), MainActivityLgn.class);
                startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}