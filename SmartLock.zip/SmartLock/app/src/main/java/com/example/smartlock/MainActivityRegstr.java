package com.example.smartlock;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivityRegstr extends AppCompatActivity {

    private EditText nameEditText;
    private EditText regNumEditText;
    private EditText passwordEditText;
    private Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_regstr);

        nameEditText = findViewById(R.id.usernameEditText);
        regNumEditText = findViewById(R.id.regsnumEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        registerButton = findViewById(R.id.buttonn);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString().trim();
                String regNum = regNumEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                if (TextUtils.isEmpty(name)) {
                    nameEditText.setError("Please enter your name");
                    return;
                }

                if (TextUtils.isEmpty(regNum)) {
                    regNumEditText.setError("Please enter your registration number");
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    passwordEditText.setError("Please enter your password");
                    return;
                }

                Toast.makeText(MainActivityRegstr.this, "Registration successful.. One step to start your journey", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getBaseContext(), MainActivityLgn.class);
                startActivity(intent);
                finish(); // close this activity and go back to login page
            }
        });
    }
}