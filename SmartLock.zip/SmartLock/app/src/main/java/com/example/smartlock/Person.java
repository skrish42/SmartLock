package com.example.smartlock;

import android.widget.Button;

public class Person {
    int Image;
    String Name;
    String Room;
    static String PhNumber;

//    int B1;



    public Person(int image, String name, String room, String phNumber) {
        Image = image;
        Name = name;
        Room = room;
        PhNumber = phNumber;
//        B1 = b1;
    }
//    public int getB1() {
//        return B1;
//    }
//
//    public void setB1(int b1) {
//        B1 = b1;
//    }




    public int getImage() {
        return Image;
    }

    public void setImage(int image) {
        Image = image;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public static String getPhNumber() {
        return PhNumber;
    }

    public void setPhNumber(String phNumber) {
        PhNumber = phNumber;
    }

    public String getRoom() {
        return Room;
    }

    public void setRoom(String room) {
        Room = room;
    }
}
