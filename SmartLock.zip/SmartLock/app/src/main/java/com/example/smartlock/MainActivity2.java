package com.example.smartlock;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    Button btn1,btn2,btn3,btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        Toast.makeText(getApplicationContext(),"Welcome to LockMe !! \n Choose your option", Toast.LENGTH_LONG).show();

        btn1 = findViewById(R.id.a);
        btn2 = findViewById(R.id.b);
        btn3 = findViewById(R.id.c);
        btn4 = findViewById(R.id.d);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivityHome.class);
                startActivity(intent);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity3.class);
                startActivity(intent);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivityFire.class);
                startActivity(intent);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivityWait.class);
                startActivity(intent);
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_item1:
                Toast.makeText(getApplicationContext(),"You are taken to Home page", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getBaseContext(), MainActivityHome.class);
                startActivity(intent);
                return true;
            case R.id.menu_item2:
                Toast.makeText(getApplicationContext(),"You are taken to About page", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(getBaseContext(), MainActivityAbt.class);
                startActivity(intent1);
                return true;
            case R.id.menu_item3:
                Toast.makeText(getApplicationContext(),"Thank you, come again !", Toast.LENGTH_SHORT).show();
                Intent intent2 = new Intent(getBaseContext(), MainActivityLgn.class);
                startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}