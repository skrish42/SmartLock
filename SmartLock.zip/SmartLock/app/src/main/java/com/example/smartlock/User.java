package com.example.smartlock;

public class User {
    private String name;
    private String id;
    private String roomNum;

    public User() {}

    public User(String name, String id, String roomNum) {
        this.name = name;
        this.id = id;
        this.roomNum = roomNum;

    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String getRoomNum() {
        return roomNum;
    }


}

