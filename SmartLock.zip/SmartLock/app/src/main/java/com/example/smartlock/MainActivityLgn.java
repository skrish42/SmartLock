package com.example.smartlock;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivityLgn extends AppCompatActivity {

    Button btn;
    EditText username;
    EditText password, regsNum;

    TextView regst, forgt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_lgn);

        username = findViewById(R.id.usernameEditText);
        password = findViewById(R.id.passwordEditText);
        regsNum = findViewById(R.id.regsnumEditText);
        regst = findViewById(R.id.register);
        forgt = findViewById(R.id.forgot);
        btn = findViewById(R.id.buttonn);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String regNum = regsNum.getText().toString().trim();
                if (TextUtils.isEmpty(regNum)) {
                    regsNum.setError("Please enter your registration number");
                    return;
                }

                if (username.getText().toString().equals("user") && password.getText().toString().equals("1234")) {
                    Intent intent = new Intent(getBaseContext(), MainActivity2.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(MainActivityLgn.this, "Oops.. Check your login mate !", Toast.LENGTH_SHORT).show();
                }


            }
        });

        regst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivityRegstr.class);
                startActivity(intent);
            }
        });

        forgt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivityLgn.this, "Sorry, service not available. Better luck next time !!!", Toast.LENGTH_SHORT).show();
            }
        });


    }
}