package com.example.smartlock;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivitySupport extends AppCompatActivity {

    EditText name, feedback;
    Button button;
    SharedPreferences sp;
    String nameStr, feedStr, nameReceive, feedReceive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_support);

        name = findViewById(R.id.edit_name);
        feedback = findViewById(R.id.edit_feedback);
        button = findViewById(R.id.b1);

        sp = getSharedPreferences("MyUserPrefs", Context.MODE_PRIVATE);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nameStr = name.getText().toString();
                feedStr = feedback.getText().toString();

                SharedPreferences.Editor editor = sp.edit();
                editor.putString("name", nameStr);
                editor.putString("feedback", feedStr);

                editor.commit();

                sp = getSharedPreferences("MyUserPrefs", Context.MODE_PRIVATE);

// Get the user's name and feedback from the SharedPreferences
                nameReceive = sp.getString("name", "");
                feedReceive = sp.getString("feedback", "");

// Use the user's name and feedback as needed
                Toast.makeText(MainActivitySupport.this, "Thanks " + nameReceive + " for your valuable feedback of " + feedReceive +
                        ". We shall keep improving", Toast.LENGTH_LONG).show();

            }
        });

        // Get an instance of SharedPreferences



    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_item1:
                Toast.makeText(getApplicationContext(),"You are taken to Home page", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getBaseContext(), MainActivityHome.class);
                startActivity(intent);
                return true;
            case R.id.menu_item2:
                Toast.makeText(getApplicationContext(),"You are taken to About page", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(getBaseContext(), MainActivityAbt.class);
                startActivity(intent1);
                return true;
            case R.id.menu_item3:
                Toast.makeText(getApplicationContext(),"Thank you, come again !", Toast.LENGTH_SHORT).show();
                Intent intent2 = new Intent(getBaseContext(), MainActivityLgn.class);
                startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}