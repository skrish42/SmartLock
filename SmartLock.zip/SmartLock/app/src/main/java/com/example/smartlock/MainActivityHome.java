package com.example.smartlock;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.NotificationCompat;

import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivityHome extends AppCompatActivity {
    Button c1, c2, c3, c4, c5, c6, c7, c8, c9;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_home);
        c1 = findViewById(R.id.Hombt1);
        c2 = findViewById(R.id.Hombt2);
        c3 = findViewById(R.id.Hombt3);
        c4 = findViewById(R.id.Hombt4);
        c5 = findViewById(R.id.Hombt5);
        c6 = findViewById(R.id.Hombt6);
        c7 = findViewById(R.id.Hombt7);
        c8 = findViewById(R.id.Hombt8);
        c9 = findViewById(R.id.Hombt9);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivityBlog.class);
                startActivity(intent);
            }
        });
        c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity5.class);
                startActivity(intent);
            }
        });

        c3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivitySample.class);
                startActivity(intent);
            }
        });

        c5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivityLocate.class);
                startActivity(intent);
            }
        });

        c9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivitySupport.class);
                startActivity(intent);
            }
        });


        // TimePicker Dialog
        c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                final Calendar c = Calendar.getInstance();
//                int hour = c.get(Calendar.HOUR_OF_DAY);
//                int minute = c.get(Calendar.MINUTE);
//                TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivityHome.this,
//                        new TimePickerDialog.OnTimeSetListener() {
//                            @Override
//                            public void onTimeSet(TimePicker view, int hourOfDay,
//                                                  int minute) {
//                                Toast.makeText(MainActivityHome.this, hourOfDay + ":" + minute, Toast.LENGTH_LONG).show();
//                            }
//                        }, hour, minute, false);
//                timePickerDialog.show();
//
//            }

            // Date Picker Dialog
//           Initialize calendar instance with current date
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            // Create DatePickerDialog and show it
            DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivityHome.this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                    // Do something with the selected date
                    String selectedDate = day + "/" + (month + 1) + "/" + year;
                    Toast.makeText(MainActivityHome.this, "Selected date: " + selectedDate, Toast.LENGTH_SHORT).show();
                }
            }, year, month, day);

              datePickerDialog.show();
//
        }

        });


        //Status Notification
        String channelId = "my_channel_id";
        String channelName = "My Channel";
        int importance = NotificationManager.IMPORTANCE_HIGH;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, channelName, importance);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }


        c6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivityHome.this, channelId)
                        .setSmallIcon(R.drawable.lock)
                        .setContentTitle("My Notification")
                        .setContentText("Someone has entered the room")
                        .setPriority(NotificationCompat.PRIORITY_HIGH);

//                NotificationManagerCompat managerCompat = NotificationManagerCompat.from(MainActivityHome.this);
//                managerCompat.notify(1, builder.build());

                NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                mNotificationManager.notify(001, builder.build());

            }
        });


        // Progress Dialog
        ProgressDialog progress=new ProgressDialog(this);

        c7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Progress bar
                progress.setMessage("Proceeding to bio-lock");
                progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                // progress.setIndeterminate(true);
                progress.setProgress(0);
                progress.show();
                final int totalProgressTime = 100;
                final Thread t = new Thread() {
                    @Override
                    public void run() {
                        int jumpTime = 0;
                        while(jumpTime < totalProgressTime) {
                            try {
                                Thread.sleep(200);
                                jumpTime += 5;
                                progress.setProgress(jumpTime);
                            } catch (InterruptedException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                        }
                        progress.dismiss();
                        if (jumpTime == totalProgressTime) {
                            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            startActivity(cameraIntent);
                        }
                    }
                };
                t.start();
//                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                startActivity(takePictureIntent);
            }
        });

        c8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivityAbt.class);
                startActivity(intent);
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

        @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_item1:
                Toast.makeText(getApplicationContext(),"You are taken to Home page", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getBaseContext(), MainActivityHome.class);
                startActivity(intent);
                return true;
            case R.id.menu_item2:
                Toast.makeText(getApplicationContext(),"You are taken to About page", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(getBaseContext(), MainActivityAbt.class);
                startActivity(intent1);
                return true;
            case R.id.menu_item3:
                Toast.makeText(getApplicationContext(),"Thank you, come again !", Toast.LENGTH_SHORT).show();
                Intent intent2 = new Intent(getBaseContext(), MainActivityLgn.class);
                startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}